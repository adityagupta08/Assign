import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  Pid :number;
  // Pradio:string="123";
  Pname:string;
  Pcost:number;
  
  PCategory:string;
  selectedBox:string[]=[];
 
 
   category: string[] = ["Grocery", "Mobile", "Electronics", "Clothes"];
   store:string[]=["BigBazar" , "Dmart","Reliance","Mega Store"];

//  onSubmit()
//  {
//   console.log(this.Pradio);
//  }
// getCheckBox(value){

// this.v1=value;
// this.v2=value;
// this.v3=value;
// this.v4=value;



   
//  }
getCheckBox(b,i)
{
  if(this.selectedBox[i]==undefined){
  this.selectedBox[i]=b;
}
else
{
  this.selectedBox[i]=undefined;
}
  console.log(this.selectedBox[0]);
    console.log(this.selectedBox[1]);
      console.log(this.selectedBox[2]);
        console.log(this.selectedBox[3]);
} 

check(i)
{
  if(this.selectedBox[i]==undefined)
  {
    return false;
  }
}



onSubmit(form){

  console.log("Product Id :" + this.Pid);
  console.log("Product Name :" + this.Pname);
  console.log("Product Cost :" + this.Pcost);
  let a = form.controls['radio'].value;
  console.log("Product is online ? :" + a);
  let b = form.controls['checkbox'];
 
  console.log("Product category :" + this.PCategory);
   console.log(b);

// console.log(this.v1);

}




}
