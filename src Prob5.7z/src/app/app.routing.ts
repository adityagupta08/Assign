import {MovieComponent} from './movie/movie.component';
import {SearchMovieComponent} from './search-movie/search-movie.component';


export const AppRoutes: any =[
    {path:"addMovie", component:MovieComponent},
    {path:"searchMovie", component:SearchMovieComponent},
   

];

export const AppComponents: any =[

    MovieComponent,
    SearchMovieComponent
   
];
